export class Category {
    category!: string;
}
